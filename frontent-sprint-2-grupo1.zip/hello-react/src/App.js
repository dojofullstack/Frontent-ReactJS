import logo from './logo.svg';
import './App.css';


function App() {
  return (
    <>
        <h1>Hola Dojo</h1>
      <p>mas informacion</p>
    </>

  );
}

export default App;
