


const Seach = () => {
    return (
        <input placeholder="buscador de productos" />
    )
}

const Header = () => {


    return (
        <>
            <header>
                <img height='150px' src="https://static.mercadonegro.pe/wp-content/uploads/2020/02/22191017/Sin-uiiug.png" />
                <h1>Tienda Virtual</h1>
                <Seach/>
            </header>
        </>
    )

}



export default Header;
