



const Footer = () => {


    return (
        <>
            <footer>
                <p>Enlaces secundarios...</p>
            </footer>
        </>
    )

}



export default Footer;
